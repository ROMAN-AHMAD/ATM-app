package bank.management.system;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUp2 extends JFrame implements ActionListener {
    String formNo;

    JComboBox combo,combo1,combo2,combo3;
    JTextField txtpane,txtCnic;
    JRadioButton s1,s2,e1,e2;

    public SignUp2(String formNo) {

        super("Application Form");

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(150, 110, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(150, 10, 100, 100);
        add(image);

        this.formNo = formNo;

        JLabel l1=new JLabel("Page 2");
        l1.setBounds(700, 10, 600, 50);
        l1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l1);

        JLabel l2=new JLabel("Additional Information");
        l2.setBounds(300, 30, 600, 100);
        l2.setFont(new Font("Times New Roman", Font.BOLD, 35));
        add(l2);


        JLabel l3=new JLabel("Religion :");
        l3.setBounds(80, 200, 400, 40);
        l3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l3);

        String religion[] = {"Christain","Muslim","Hindu","Sikh","Other"};
         combo = new JComboBox(religion);
        combo.setBackground(new Color(200,190,156));
        combo.setFont(new Font("Raleway", Font.PLAIN, 14));
        combo.setBounds(250, 200, 200, 30);
        add(combo);

        JLabel l4=new JLabel("Income :");
        l4.setBounds(80, 240, 400, 40);
        l4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l4);

        String Income[] = {"Null","<100000","<200000","<300000",">300000"};
        combo1 = new JComboBox(Income);
        combo1.setBackground(new Color(200,190,156));
        combo1.setFont(new Font("Raleway", Font.PLAIN, 14));
        combo1.setBounds(250, 240, 200, 30);
        add(combo1);

        JLabel l5=new JLabel("Education :");
        l5.setBounds(80, 280, 400, 40);
        l5.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l5);

        String Education[] = {"illetrate","Graduate","Under-Graduate","Master","Post Graduate"};
         combo2 = new JComboBox(Education);
        combo2.setBackground(new Color(200,190,156));
        combo2.setFont(new Font("Raleway", Font.PLAIN, 14));
        combo2.setBounds(250, 280, 200, 30);
        add(combo2);

        JLabel l6=new JLabel("Occupation :");
        l6.setBounds(80, 320, 400, 40);
        l6.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l6);

        String occupation[] = {"Salaried","Student","Bussiness","Self-employed","Retired","Other"};
         combo3 = new JComboBox(occupation);
        combo3.setBackground(new Color(200,190,156));
        combo3.setFont(new Font("Raleway", Font.PLAIN, 14));
        combo3.setBounds(250, 320, 200, 30);
        add(combo3);

        JLabel l7=new JLabel("Pan No :");
        l7.setBounds(80, 360, 400, 40);
        l7.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l7);

         txtpane = new JTextField();
       // txtpane.setBackground(new Color(200,190,156));
        txtpane.setFont(new Font("Raleway", Font.PLAIN, 14));
        txtpane.setBounds(250, 360, 200, 30);
        add(txtpane);


        JLabel l8=new JLabel("CNIC No :");
        l8.setBounds(80, 400, 400, 40);
        l8.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l8);

         txtCnic = new JTextField();
        txtCnic.setFont(new Font("Raleway", Font.PLAIN, 14));
        txtCnic.setBounds(250, 400, 200, 30);
        add(txtCnic);

        //for numeric input only
        ((AbstractDocument) txtCnic.getDocument()).setDocumentFilter(new NumericDocumentFilter());
        ((AbstractDocument) txtpane.getDocument()).setDocumentFilter(new NumericDocumentFilter());


        JLabel l9=new JLabel("Senior Citizen :");
        l9.setBounds(80, 440, 400, 40);
        l9.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l9);

         s1 = new JRadioButton("Yes");
        s1.setBackground(new Color(200,190,156));
        s1.setFont(new Font("Raleway", Font.PLAIN, 14));
        s1.setBounds(250, 440, 50, 30);
        add(s1);

         s2 = new JRadioButton("No");
        s2.setBackground(new Color(200,190,156));
        s2.setFont(new Font("Raleway", Font.PLAIN, 14));
        s2.setBounds(340, 440, 80, 30);
        add(s2);


        ButtonGroup bg = new ButtonGroup();
        bg.add(s1);
        bg.add(s2);




        JLabel l10=new JLabel("Existing account :");
        l10.setBounds(80, 480, 400, 40);
        l10.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        add(l10);

         e1 = new JRadioButton("Yes");
        e1.setBackground(new Color(200,190,156));
        e1.setFont(new Font("Raleway", Font.PLAIN, 14));
        e1.setBounds(250, 480, 50, 30);
        add(e1);

         e2 = new JRadioButton("No");
        e2.setBackground(new Color(200,190,156));
        e2.setFont(new Font("Raleway", Font.PLAIN, 14));
        e2.setBounds(340, 480, 80, 30);
        add(e2);


        ButtonGroup b = new ButtonGroup();
        b.add(e1);
        b.add(e2);

        JLabel l11=new JLabel("Form No :");
        l11.setBounds(400, 10, 400, 40);
        l11.setBackground(Color.BLACK);
        l11.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(l11);

        JLabel l12=new JLabel(formNo );
        l12.setBounds(500, 10, 400, 40);
        l12.setFont(new Font("Raleway", Font.PLAIN, 18));
        add(l12);





        JButton next = new JButton("Next");
        next.setBackground(new Color(200,190,156));
        next.setFont(new Font("Raleway", Font.PLAIN, 14));
        next.setBounds(400, 600, 80, 40);
        next.addActionListener(this);
        add(next);






        setLayout(null);
        setSize(850, 750);
        setLocation(200 , 40);
        getContentPane().setBackground(new Color(190,190,156));
        setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {


        String rel = (String) combo.getSelectedItem();
        String income = (String) combo1.getSelectedItem();
        String occuption = (String) combo3.getSelectedItem();
        String edu = (String) combo2.getSelectedItem();

        String pan = (String) txtpane.getText();
        String cnic = (String) txtCnic.getText();


        String sen = null ;
        String Ex=null ;

        if(s1.isSelected()){
            sen = "yes";
        }else if(s2.isSelected()){
            sen = "NO";
        }

        if(e1.isSelected()){
            Ex = "yes";
        }else if(e2.isSelected()){
            Ex = "NO";
        }


        try{
            if(txtpane.getText().equals("")||txtCnic.getText().equals("")){
                JOptionPane.showMessageDialog(null, "invalid input");
                return;
            }else {
                Conn con1 = new Conn();
                String q = "insert into signup2 value('"+formNo+"','"+rel+"','"+income+"','"+edu+"','"+occuption+"','"+pan+"','"+cnic+"','"+sen+"','"+Ex+"')";
                con1.statement.executeUpdate(q);
                new SignUp3(formNo);
                setVisible(false);
            }


        }catch (Exception E){
            E.printStackTrace();
        }





    }
    public static void main(String[] args) {
        new SignUp2("");
    }


}
