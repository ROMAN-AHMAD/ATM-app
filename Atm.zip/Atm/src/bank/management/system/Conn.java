package bank.management.system;

import java.sql.*;

public class Conn {

        Connection connection;
        Statement statement;
    public Conn(){
        try{
            //for connecting with database
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banksystem","root","1234" );
                statement = connection.createStatement();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

        public static void main(String[] args) {
            new Conn();
        }
}
