package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class Deposit extends JFrame implements ActionListener {
    String pin;
    JTextField textField;
    JButton Dep, Back;


    public Deposit(String pin){


        super("Deposit");


        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.jpg"));
        Image image = icon.getImage().getScaledInstance(1200,650 ,Image.SCALE_DEFAULT);
        ImageIcon icon1 = new ImageIcon(image);
        JLabel label = new JLabel(icon1);
        label.setBounds(0,0,1200,650);
        add(label);

        JLabel label1 = new JLabel("Enter amount you want to Deposit");
        label1.setFont(new Font("System", Font.BOLD, 13));
        label1.setBounds(380,230,400,30);
        label.add(label1);

        textField = new JTextField();
        textField.setFont(new Font("System", Font.BOLD , 18));
        textField.setBounds(380,260,240,30);
        textField.setForeground(Color.WHITE);
        textField.setBackground(Color.GRAY);
        label.add(textField);

        Dep = new JButton("Deposit");
        Dep.setFont(new Font("System", Font.BOLD, 13));
        Dep.setBounds(380,300,100,30);
        Dep.setBackground(Color.BLACK);
        Dep.setForeground(Color.white);
        Dep.addActionListener(this);
        label.add(Dep);


        Back = new JButton("Back");
        Back.setFont(new Font("System", Font.BOLD, 13));
        Back.setBounds(500,300,100,30);
        Back.setBackground(Color.BLACK);
        Back.setForeground(Color.white);
        Back.addActionListener(this);
        label.add(Back);





















        this.pin = pin;
        setSize(1500,1000);
        setLayout(null);
        setLocation(0,0);
        setVisible(true);



    }

    public static void main(String[] args) {
        new Deposit("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String amount = textField.getText();
        Date date = new Date();

        try {
            if(e.getSource()==Dep){
                if(textField.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Enter amount you want to Deposit");
                }else{
                    Conn con = new Conn();
                    con.statement.executeUpdate("insert into Bank values ('"+pin+"','"+date+"','deposit','"+amount+"')") ;
                    JOptionPane.showMessageDialog(null, "Rs  "+amount+"   Deposited Successfully");

                    setVisible(false);
                    new Main_class(pin);
                }
            }else if(e.getSource() == Back){
                setVisible(false);
            }

        }catch (Exception e1) {
            e1.printStackTrace();
        }


    }
}
