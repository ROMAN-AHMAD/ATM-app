package bank.management.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.Period;
import java.util.Random;

public class Signup extends JFrame implements ActionListener {


    JButton next;

    JTextField txtName, txtFname,txtEmail, txtPin,txtaddress,txtcity ,txtState;

    JDateChooser dateChooser;

    JRadioButton r1, r2,r3, m1,m2;


// For random number generation
    Random rand = new Random();
    long num = (rand.nextLong() % 9000L) +1000L;
    String first = " "+ Math.abs(num);

    Signup() {

        //title
        super("Application form");

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(150, 110, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(20, 10, 100, 100);
        add(image);


        JLabel label1 = new JLabel("Applicaion Form No: "+first);
        label1.setBounds(160, 20, 600, 40);
        label1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        label1.setForeground(Color.black);
        add(label1);

        JLabel label2 = new JLabel("Page No: 1");
        label2.setBounds(700, 20, 100, 40);
        label2.setFont(new Font("Raleway",Font.BOLD , 18));
        add(label2);


        JLabel label3 = new JLabel("Personal Details");
        label3.setBounds(350, 100, 400, 40);
        label3.setFont(new Font("Times New Roman",Font.BOLD , 20));
        add(label3);

        JLabel Name = new JLabel("Name : ");
        Name.setBounds(50, 200, 200, 20);
        Name.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(Name);

        txtName = new JTextField();
        txtName.setBounds(200, 200, 300, 20);
        txtName.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtName);


        JLabel Fname = new JLabel("Father Name : ");
        Fname.setBounds(50, 240, 200, 20);
        Fname.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(Fname);

        txtFname = new JTextField();
        txtFname.setBounds(200, 240, 300, 20);
        txtFname.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtFname);


        JLabel DOB = new JLabel("Date Of Birth : ");
        DOB.setBounds(50, 280, 200, 20);
        DOB.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(DOB);

        dateChooser = new JDateChooser();
        dateChooser.setForeground(new Color(105, 105, 105));
        dateChooser.setBounds(200, 280, 300, 20);
        add(dateChooser);

        JLabel gender = new JLabel("Gender : ");
        gender.setBounds(50, 320, 200, 20);
        gender.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(gender);

        r1 = new JRadioButton("Male");
        r1.setBounds(200, 320, 80, 20);
        r1.setFont(new Font("Tahoma",Font.PLAIN, 16));
        r1.setBackground(new Color(222,255,228));
        add(r1);

        r2 = new JRadioButton("Female");
        r2.setBounds(280, 320, 80, 20);
        r2.setFont(new Font("Tahoma",Font.PLAIN, 16));
        r2.setBackground(new Color(222,255,228));
        add(r2);


        r3 = new JRadioButton("Other");
        r3.setBounds(380, 320, 80, 20);
        r3.setFont(new Font("Tahoma",Font.PLAIN, 16));
        r3.setBackground(new Color(222,255,228));
        add(r3);

        ButtonGroup  buttonGroup= new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);
        buttonGroup.add(r3);




        JLabel email = new JLabel("Email : ");
        email.setBounds(50, 360, 200, 20);
        email.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(email);

        txtEmail = new JTextField();
        txtEmail.setBounds(200, 360, 300, 20);
        txtEmail.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtEmail);


        JLabel marital = new JLabel("Marital Status : ");
        marital.setBounds(50, 400, 200, 20);
        marital.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(marital);

       m1 = new JRadioButton("Married");
       m1.setBounds(200, 400, 80, 20);
       m1.setFont(new Font("Tahoma",Font.PLAIN, 16));
       m1.setBackground(new Color(222,255,228));
       add(m1);

       m2 = new JRadioButton("Unmarried");
       m2.setBounds(280, 400, 150, 20);
       m2.setFont(new Font("Tahoma",Font.PLAIN, 16));
       m2.setBackground(new Color(222,255,228));
       add(m2);

       ButtonGroup group = new ButtonGroup();
       group.add(m1);
       group.add(m2);


        JLabel Address = new JLabel("Address : ");
        Address.setBounds(50, 440, 200, 20);
        Address.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(Address);

        txtaddress = new JTextField();
        txtaddress.setBounds(200, 440, 300, 20);
        txtaddress.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtaddress);


        JLabel City = new JLabel("City : ");
        City.setBounds(50, 480, 200, 20);
        City.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(City);

        txtcity = new JTextField();
        txtcity.setBounds(200, 480, 300, 20);
        txtcity.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtcity);



        JLabel PinCode = new JLabel("Pin Code : ");
        PinCode.setBounds(50, 520, 200, 20);
        PinCode.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(PinCode);

        txtPin = new JTextField();
        txtPin.setBounds(200, 520, 300, 20);
        txtPin.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtPin);

        ((AbstractDocument) txtPin.getDocument()).setDocumentFilter(new NumericDocumentFilter());




        JLabel State = new JLabel("State : ");
        State.setBounds(50, 560, 200, 20);
        State.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(State);

        txtState = new JTextField();
        txtState.setBounds(200, 560, 300, 20);
        txtState.setFont(new Font("Tahoma",Font.PLAIN, 16));
        add(txtState);



        next = new JButton("Next");
        next.setBounds(600, 600, 100, 40);
        next.setFont(new Font("Tahoma",Font.PLAIN, 16));
        next.setForeground(Color.black);
        next.setBackground(Color.CYAN);
        next.addActionListener(this);
        add(next);





        getContentPane().setBackground(new Color(222,255,228));
        setLayout(null);
        setSize(850,800);
        setLocation(360,40);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String formNo = first;
        String name = txtName.getText();
        String fname = txtFname.getText();
        String email = txtEmail.getText();

        String aaddress = txtaddress.getText();
        String city = txtcity.getText();
        String pin = txtPin.getText();
        String state = txtState.getText();


        String marital = null;

        if(m1.isSelected())
        {
            marital = "Married";
        }else if(m2.isSelected()){
            marital = "Unmarried";
        }


        String gender = null;
        if(r1.isSelected()){
            gender = "Male";
        }else if(r2.isSelected()){
            gender = "Female";
        }else if(r3.isSelected()){
            gender = "other";
        }





        //For Putting date of birth in string;
        String Dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
      //  int age = Period.between(LocalDate.parse((CharSequence) dateChooser), LocalDate.now()).getYears();


        try{
            if(txtName.getText().equals("")){

                JOptionPane.showMessageDialog(null, "Fill all the fields");
            } else if (txtEmail.getText().equals("")) {

                JOptionPane.showMessageDialog(null, "Fill all the fields");
            } else if (txtPin.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Fill all the fields");
            } else {
                Conn con1 = new Conn();
                String q = "insert into signup value('" + formNo + "','" + name + "','" + fname + "','" + Dob + "','" + gender + "','" + email + "','" + marital + "','" + aaddress + "','" + city + "','" + pin + "','" + state + "')";
                con1.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null, "Signup Successful");
                new SignUp2(formNo);
                setVisible(false);
            }

        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Signup();
    }



}
