package bank.management.system;

import javax.swing.*;/*Comes with Jframe extension */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
    JLabel label1, label2, label3;

    JTextField tf1;

    JPasswordField tf2;

    JButton signup,login,Clear;

    Login(){
        /* constructor */
        super("Bank Management System Login"); /*It is the title of frame */

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(350, 10, 100, 100);
        add(image);

        ImageIcon ii1= new ImageIcon(ClassLoader.getSystemResource("icon/card.png"));
        Image ii2 = ii1.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon ii3 = new ImageIcon(ii2);
        JLabel iimage= new JLabel(ii3);
        iimage.setBounds(600, 350, 100, 100);
        add(iimage);

        label1 = new JLabel("WELCOME TO ATM");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        label1.setBounds(300, 125, 450, 40);
        add(label1);

        label3 = new JLabel("Enter CARD No:");
        label3.setForeground(Color.WHITE);
        label3.setFont(new Font("Times New Roman", Font.BOLD, 15));
        label3.setBounds(130, 220, 450, 20);
        add(label3);

        tf1 = new JTextField(15  );
      //  tf1.setForeground(Color.WHITE);
        tf1.setFont(new Font("Times New Roman", Font.BOLD, 15));
        tf1.setBounds(280 , 220, 450, 20);
        add(tf1);

        //For PIN
        label2 = new JLabel("Enter your PIN:");
        label2.setForeground(Color.WHITE);
        label2.setFont(new Font("Times New Roman", Font.BOLD, 15));
        label2.setBounds(130, 260, 450,20 );
        add(label2);

        tf2 = new JPasswordField(15  );
        //  tf1.setForeground(Color.WHITE);
        tf2.setFont(new Font("Times New Roman", Font.BOLD, 15));
        tf2.setBounds(280 , 260, 450, 20);
        add(tf2);



        signup = new JButton("SIGN UP");
        signup.setFont(new Font("Times New Roman", Font.BOLD, 15));
        signup.setForeground(Color.black);
        signup.setBounds(340,360, 180, 30);
        signup.addActionListener(this);
        add(signup);



        login = new JButton("LOGIN");
        login.setFont(new Font("Times New Roman", Font.BOLD, 15));
        login.setForeground(Color.black);
        login.setBounds(300, 300, 100, 30);
        login.addActionListener(this);
        add(login);


        Clear = new JButton("CLEAR");
        Clear.setFont(new Font("Times New Roman", Font.BOLD, 15));
        Clear.setForeground(Color.black);
        Clear.setBounds(450, 300, 100, 30);
        Clear.addActionListener(this);
        add(Clear);



        // For background image
        ImageIcon iii1= new ImageIcon(ClassLoader.getSystemResource("icon/backbg.png"));
        Image iii2 = iii1.getImage().getScaledInstance(850, 480, Image.SCALE_SMOOTH);
        ImageIcon iii3 = new ImageIcon(iii2);
        JLabel iiimage= new JLabel(iii3);
        iiimage.setBounds(0, 0, 850, 480);
        add(iiimage);






        setLayout(null);
        setSize(  850, 480);/*Size of the frame */
        setLocation(200,100);/*Opens at which location*/
        setVisible(true);/*Make it visible to user */
    }

    @Override
    public void actionPerformed(ActionEvent e) {

            try{
                if(e.getSource() == signup){
                    new Signup();
                    setVisible(false);

                }else if(e.getSource() == login) {
                    Conn c = new Conn();
                    String cardno = tf1.getText();
                    String pin = tf2.getText();
                    String q = "select * from login where card_no = '" + cardno + "' and  Pin_no = '" + pin + "'";
                    ResultSet resultSet = c.statement.executeQuery(q);
                    if (resultSet.next()) {
                        setVisible(false);
                        new Main_class(pin);
                    } else {
                        JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");

                    }
                    }else if (e.getSource() == Clear) {
                        tf1.setText("");
                        tf2.setText("");
                    }

            }catch (Exception E){
                E.printStackTrace();
            }
    }

    public static void main(String[] args) {
    new Login();




    }
}
