package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SignUp3 extends JFrame implements ActionListener {
    JCheckBox b1,b2,b3,b4,b5,b6;
    String formno;
    JRadioButton r1,r2,r3,r4;
    JButton button,button1;

    SignUp3(String formno){

        this.formno = formno;

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(150, 110, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(150, 10, 100, 100);
        add(image);

        JLabel l1=new JLabel("Page 3 :");
        l1.setBounds(280, 10, 100, 100);
        l1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(l1);

        JLabel l2=new JLabel("Account Details :");
        l2.setBounds(280, 50, 600, 100);
        l2.setFont(new Font("Times New Roman", Font.BOLD, 25));
        add(l2);

        JLabel l3=new JLabel("Acount type :");
        l3.setBounds(100, 100, 500, 100);
        l3.setFont(new Font("Raleway", Font.BOLD, 20));
        add(l3);

         r1= new JRadioButton("Saving Account");
        r1.setBounds(150, 180, 200, 20);
        r1.setBackground(new Color(215,252,252));
        r1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(r1);

         r2=new JRadioButton("Fixed Deposit Account");
        r2.setBounds(150, 220, 230, 20);
        r2.setBackground(new Color(215,252,252));
        r2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(r2);

         r3=new JRadioButton("Current Account");
        r3.setBounds(450, 180, 230, 20);
        r3.setBackground(new Color(215,252,252));
        r3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(r3);

         r4=new JRadioButton("Deposit Account");
        r4.setBounds(450, 220, 230, 20);
        r4.setBackground(new Color(215,252,252));
        r4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(r4);

        ButtonGroup bg=new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        bg.add(r3);
        bg.add(r4);

        JLabel l4=new JLabel("Card number :");
        l4.setBounds(100, 250, 500, 100);
        l4.setFont(new Font("Raleway", Font.BOLD, 18));
        add(l4);

        JLabel l5=new JLabel("(Your card is 16 digit number)");
        l5.setBounds(100, 280, 400, 100);
        l5.setFont(new Font("Raleway", Font.BOLD, 12));
        add(l5);

        JLabel l6 = new JLabel("XXXX-XXXX-XXXX-4321");
        l6.setBounds(400, 250, 400, 100);
        l6.setFont(new Font("Raleway", Font.BOLD, 16));
        add(l6);

        JLabel l7 = new JLabel("It would appear on Card/Cheque");
        l7.setBounds(400, 280, 400, 100);
        l7.setFont(new Font("Raleway", Font.BOLD, 12));
        add(l7);


        JLabel l8 = new JLabel("Pin :");
        l8.setBounds(100, 320, 400, 100);
        l8.setFont(new Font("Raleway", Font.BOLD, 16));
        add(l8);

        JLabel l9 = new JLabel("XXXX");
        l9.setBounds(400, 320, 400, 100);
        l9.setFont(new Font("Raleway", Font.BOLD, 14));
        add(l9);

        JLabel l10 = new JLabel("(4-digit Pin number)");
        l10.setBounds(100, 340, 400, 100);
        l10.setFont(new Font("Raleway", Font.BOLD, 12));
        add(l10);

        JLabel l11 = new JLabel("Services Required ");
        l11.setBounds(100, 380, 400, 100);
        l11.setFont(new Font("Raleway", Font.BOLD, 16));
        add(l11);

        b1 = new JCheckBox("ATM Card");
        b1.setBounds(120, 450, 100, 20);
        b1.setBackground(new Color(215,252,252));
        b1.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b1);

        b2 = new JCheckBox("Internet Banking");
        b2.setBounds(400, 450, 300, 20);
        b2.setBackground(new Color(215,252,252));
        b2.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b2);

        b3 = new JCheckBox("Mobile Banking");
        b3.setBounds(120, 490, 300, 20);
        b3.setBackground(new Color(215,252,252));
        b3.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b3);

        b4 = new JCheckBox("Email alert");
        b4.setBounds(400, 490, 100, 20);
        b4.setBackground(new Color(215,252,252));
        b4.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b4);

        b5 = new JCheckBox("Cheque book");
        b5.setBounds(120, 530, 300, 20);
        b5.setBackground(new Color(215,252,252));
        b5.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b5);


        b6 = new JCheckBox("E-statement");
        b6.setBounds(400, 530, 300, 20);
        b6.setBackground(new Color(215,252,252));
        b6.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(b6);

        JLabel l12 = new JLabel("Form No :");
        l12.setBounds(600, 10, 400, 100);
        l12.setFont(new Font("Raleway", Font.BOLD, 14));
        add(l12);

        JLabel l13 = new JLabel(formno);
        l13.setBounds(690, 10, 400, 100);
        l13.setFont(new Font("Raleway", Font.BOLD, 14));
        add(l13);




        JCheckBox checkBox = new JCheckBox("I hereby accept that the above is correct to my Knowledge",true);
        checkBox.setBounds(120, 600, 600, 20);
        checkBox.setBackground(new Color(215,252,252));
        checkBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
        add(checkBox);

         button = new JButton("Submit");
        button.setBounds(400, 650, 100, 40);
        button.setBackground(Color.GRAY);
        button.setFont(new Font("Times New Roman", Font.BOLD, 14));
        button.setForeground(Color.white);
        button.addActionListener(this);
        add(button);

         button1 = new JButton("Cancel");
        button1.setBounds(550, 650, 100, 40);
        button1.setBackground(Color.GRAY);
        button1.setFont(new Font("Times New Roman", Font.BOLD, 14));
        button1.setForeground(Color.white);
        button1.addActionListener(this);
        add(button1);







    setSize(850 ,750);
    setLocationRelativeTo(null);
    getContentPane().setBackground(new Color(215,252,252));

    setLayout(null);
    setVisible(true);


    }

    public static void main(String[] args) {
        new SignUp3(" ");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String Atype = null;

        if(r1.isSelected()){
            Atype = "Saving account";
        } else if (r2.isSelected()) {
            Atype = "Fixed Deposit Account";

        }else if (r3.isSelected()) {
            Atype = "Current Account";
        }else if (r4.isSelected()) {
            Atype = "Deposit Account";
        }

        Random ran = new Random();
        long Q = (ran.nextLong()% 90000000L) +14378650000000L;
        String Cnum =""+Math.abs(Q);


        Random ran1 = new Random();
        long W = (ran1.nextLong()% 9000L) +1000L;
        String PinNo =""+Math.abs(W);


        String facility = "";

        if(b1.isSelected()){
            facility += "ATM Card";
        }else if(b2.isSelected()){
            facility += "Internet Banking";

        }else if(b3.isSelected()){
            facility += "Mobile Banking";
        }else if(b4.isSelected()){
            facility += "Email alert";

        }else if(b5.isSelected()){
            facility += "Cheque book";
        } else if (b6.isSelected()) {
            facility += "E-statement";

        }

        try {
            if (e.getSource() == button) {
                if (Atype.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid type");
                } else {
                    Conn con = new Conn();
                    String val = "insert into signup3 values('" + formno + "','" + Atype + "','" + Cnum + "','" + PinNo + "','" + facility + "')";
                    String val1 = "insert into login values('" + formno + "','" + Cnum + "','" + PinNo + "')";
                     con.statement.executeUpdate(val);
                    con.statement.executeUpdate(val1);

                    JOptionPane.showMessageDialog(null, "Card No : " + Cnum + "\nPin :" + PinNo);
                    new Deposit(PinNo);
                    setVisible(false);
                }

            } else if (e.getSource() == button1) {
                System.exit(0);
            }
        }
        catch(Exception ex){
                ex.printStackTrace();
            }

    }
}
